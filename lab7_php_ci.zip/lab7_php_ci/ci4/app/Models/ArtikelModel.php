<?php

namespace App\Models;

use CodeIgniter\Model;

class ArtikelModel extends Model
{
    protected $table = 'artikel';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['judul', 'isi', 'status', 'slug', 'gambar'];
    protected $useTimestamps = true;      // Aktifkan timestamp otomatis
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Optional: Untuk mengambil artikel terbaru
    public function getTerbaru($limit = 5)
    {
        return $this->orderBy('created_at', 'DESC')->findAll($limit);
    }
}