<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;
use App\Models\ArtikelModel;

class ArtikelTerkini extends Cell
{
    protected $kategori = null;
    protected $limit = 5;

    public function mount($kategori = null, $limit = 5)
    {
        $this->kategori = $kategori;
        $this->limit = $limit;
    }

    public function render()
    {
        $model = new ArtikelModel();
        
        $query = $model->orderBy('created_at', 'DESC');
        
        // Filter berdasarkan kategori (bisa dikembangkan dengan menambah kolom kategori)
        if ($this->kategori) {
            $query->like('judul', $this->kategori);
        }
        
        $artikel = $query->findAll($this->limit);
        
        return view('components/artikel_terkini', [
            'artikel' => $artikel,
            'kategori' => $this->kategori
        ]);
    }
}