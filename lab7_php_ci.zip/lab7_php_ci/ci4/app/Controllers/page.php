<?php

namespace App\Controllers;

class Page extends BaseController
{
    public function about()
    {
        return view('about', [
            'title' => 'Halaman About',
            'content' => 'Ini adalah halaman about yang menjelaskan tentang isi halaman ini.'
        ]);
    }

    public function contact()
    {
        return view('contact', [
            'title' => 'Halaman Kontak',
            'content' => 'Email: info@pelitabangsa.ac.id<br>Telepon: (021) 12345678<br>Alamat: Jl. Contoh No. 123, Bekasi'
        ]);
    }

    public function faqs()
    {
        return view('faqs', [
            'title' => 'FAQ',
            'content' => '<strong>Q: Apa itu CodeIgniter?</strong><br>A: Framework PHP yang ringan dan cepat.<br><br>
                          <strong>Q: Apa itu MVC?</strong><br>A: Model-View-Controller, arsitektur pengembangan aplikasi.<br><br>
                          <strong>Q: Bagaimana cara install CI4?</strong><br>A: Download dari website resmi atau via Composer.'
        ]);
    }

    public function tos()
    {
        return view('tos', [
            'title' => 'Terms of Service',
            'content' => 'Syarat dan ketentuan penggunaan website ini.'
        ]);
    }
}