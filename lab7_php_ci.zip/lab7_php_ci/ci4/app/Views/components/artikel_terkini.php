<div class="widget-box">
    <h3 class="title">
        Artikel Terkini 
        <?= $kategori ? "<small>($kategori)</small>" : '' ?>
    </h3>
    <ul>
        <?php if (!empty($artikel)): ?>
            <?php foreach ($artikel as $row): ?>
                <li>
                    <a href="<?= base_url('/artikel/' . $row['slug']); ?>">
                        <?= esc($row['judul']); ?>
                    </a>
                    <br>
                    <small><?= date('d/m/Y', strtotime($row['created_at'])); ?></small>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
            <li>Belum ada artikel</li>
        <?php endif; ?>
    </ul>
</div>