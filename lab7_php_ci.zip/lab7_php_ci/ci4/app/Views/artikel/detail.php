<?= $this->include('template/header'); ?>
<article class="entry">
    <h2 style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
        <span><?= $artikel['judul']; ?></span>
        <small style="font-size: 12px; color: #888; font-weight: normal;">
            📅 Update: <?= date('d/m/Y H:i', strtotime($artikel['updated_at'] ?? $artikel['created_at'] ?? date('Y-m-d H:i:s'))); ?>
        </small>
    </h2>
    <img src="<?= base_url('/gambar/' . $artikel['gambar']);?>" alt="<?= $artikel['judul']; ?>">
    <p><?= $artikel['isi']; ?></p>
</article>
<?= $this->include('template/footer'); ?>