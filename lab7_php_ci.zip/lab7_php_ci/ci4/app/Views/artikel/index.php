<?= $this->include('template/header'); ?>

<?php if($artikel): foreach($artikel as $row): ?>
<article class="entry">
    <h2 style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
        <span><?= $row['judul']; ?></span>
        <small style="font-size: 12px; color: #888; font-weight: normal;">
            📅 <?= date('d/m/Y H:i', strtotime($row['updated_at'] ?? $row['created_at'] ?? date('Y-m-d H:i:s'))); ?>
        </small>
    </h2>
    <img src="<?= base_url('/gambar/' . $row['gambar']);?>" alt="<?= $row['judul']; ?>">
    <p><?= substr($row['isi'], 0, 200); ?>...</p>
    <a href="<?= base_url('/artikel/' . $row['slug']); ?>" class="btn">Selengkapnya →</a>
</article>
<hr class="divider" />
<?php endforeach; else: ?>
<article class="entry">
    <h2>Belum ada data.</h2>
</article>
<?php endif; ?>

<?= $this->include('template/artikel_footer'); ?>