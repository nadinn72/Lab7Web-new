</section>
    <aside id="sidebar">
    <div class="widget-box">
    <h3 class="title">Widget Header</h3>
    <ul>
    <li><a href="#">Widget Link</a></li>
    <li><a href="#">Widget Link</a></li>
    </ul>
    </div>
    <div class="widget-box">
    <h3 class="title">Widget Text</h3>
<p>Vestibulum lorem elit, iaculis in nisl volutpat,
malesuada tincidunt arcu. Proin in leo fringilla, vestibulum mi porta,
faucibus felis. Integer pharetra est nunc, nec pretium nunc pretium ac.</p>
    </div>
    </aside>
    </section>
    <footer style="background-color: #333; color: white; text-align: center; padding: 15px; font-size: 14px;">
        <p>&copy; 2026 - Universitas Pelita Bangsa</p>
    </footer>
    </div>
</body>
</html>
