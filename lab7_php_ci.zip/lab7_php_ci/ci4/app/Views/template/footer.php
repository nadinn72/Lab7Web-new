</section>
    <aside id="sidebar">
    </aside>
    </section>
    <footer style="background-color: #333; color: white; text-align: center; padding: 15px; font-size: 14px;">
        <p>&copy; 2026 - Universitas Pelita Bangsa</p>
    </footer>
    </div>
</body>
</html>
