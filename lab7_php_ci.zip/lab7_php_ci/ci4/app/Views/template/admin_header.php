<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal Berita</title>
    
    <!-- Link ke file CSS utama -->
    <link rel="stylesheet" href="<?= base_url('style.css') ?>">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
<sty>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Open Sans', sans-serif;
        background-color: #f4f4f4;
        color: #333;
    }
    
    .container {
        width: 1000px;
        margin: 20px auto;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    
    .header {
        background: #e8a0b4;  /* PINK SOFT - GANTI DARI BIRU */
        color: white;
        padding: 20px;
    }
    
    .header h2 {
        margin: 0;
        font-size: 20px;
    }
    
    .nav {
        background: #fef5f7;  /* PINK SANGAT SOFT */
        padding: 10px 20px;
        border-bottom: 2px solid #f5c6d0;
    }
    
    .nav a {
        display: inline-block;
        padding: 8px 15px;
        margin-right: 5px;
        color: #5a5a5a;
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        border-radius: 3px;
    }
    
    .nav a:hover, .nav a.active {
        background-color: #e8a0b4;  /* PINK SOFT */
        color: white;
    }
    
    .content {
        padding: 20px;
        min-height: 400px;
    }
    
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }
    
    table th {
        background: #e8a0b4;  /* PINK SOFT - GANTI DARI BIRU */
        color: white;
        padding: 12px;
        text-align: left;
    }
    
    table td {
        padding: 12px;
        border-bottom: 1px solid #f5c6d0;
        vertical-align: top;
    }
    
    /* Kolom ID */
    table th:first-child, table td:first-child {
        width: 70px;
        text-align: center;
    }
    
    /* Kolom Judul */
    table th:nth-child(2), table td:nth-child(2) {
        width: 500px;
    }
    
    /* Kolom Status */
    table th:nth-child(3), table td:nth-child(3) {
        width: 80px;
        text-align: center;
    }
    
    /* TOMBOL UBAH - PINK SOFT */
    .btn-edit {
        background: #e8a0b4;  /* PINK - GANTI DARI KUNING */
        color: white;
        padding: 5px 10px;
        text-decoration: none;
        border-radius: 3px;
        font-size: 12px;
        margin-right: 5px;
        display: inline-block;
        border: none;
    }
    
    .btn-edit:hover {
        background: #d48a9e;
    }
    
    /* TOMBOL HAPUS - PINK SOFT (bukan merah menyala) */
    .btn-delete {
        background: #e50039;  /* PINK LEBIH SOFT - GANTI DARI MERAH */
        color: white;
        padding: 5px 10px;
        text-decoration: none;
        border-radius: 3px;
        font-size: 12px;
        display: inline-block;
        border: none;
    }
    
    .btn-delete:hover {
        background: #d48a9e;
    }
    
    /* TOMBOL TAMBAH - PINK SOFT */
    .btn-add {
        background: #4c87da;  /* PINK - GANTI DARI HIJAU */
        color: white;
        padding: 8px 15px;
        text-decoration: none;
        border-radius: 3px;
        display: inline-block;
        margin-bottom: 15px;
        border: none;
    }
    
    .btn-add:hover {
        background: #d48a9e;
    }
    
    footer {
        background: #f4f4f4;
        text-align: center;
        padding: 15px;
        border-top: 1px solid #f5c6d0;
        font-size: 12px;
    }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>Admin Portal Berita</h1>
    </div>
    
    <div class="nav">
        <a href="<?= base_url('artikel') ?>">Dashboard</a>
        <a href="<?= base_url('admin/artikel') ?>">Artikel</a>
        <a href="<?= base_url('admin/artikel/add') ?>">Tambah Artikel</a>
    </div>
    
    <div class="content">